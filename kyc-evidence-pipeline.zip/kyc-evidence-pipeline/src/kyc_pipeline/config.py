from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .util import digest

CONFIG_DIR = Path(__file__).parent / "configs"


def _read_yaml(path: str | Path) -> tuple[dict[str, Any], str]:
    raw = Path(path).read_bytes()
    data = yaml.safe_load(raw)
    if not isinstance(data, dict):
        raise ValueError(f"Invalid YAML object: {path}")
    return data, digest(raw)


def load_contract(profiles_path: str | None = None, policy_path: str | None = None) -> dict[str, Any]:
    profiles_data, profile_hash = _read_yaml(profiles_path or CONFIG_DIR / "document_profiles.yaml")
    policy, policy_hash = _read_yaml(policy_path or CONFIG_DIR / "kyc_policy.yaml")
    profiles = profiles_data.get("profiles")
    categories = policy.get("categories")
    families = policy.get("families")
    if not isinstance(profiles, dict) or not isinstance(categories, dict) or not isinstance(families, dict):
        raise ValueError("Profiles and policy must contain profiles, categories, and families mappings")
    if not isinstance(policy.get("policy_id"), str) or not policy["policy_id"]:
        raise ValueError("The policy must have a nonempty policy_id")
    for pid, profile in profiles.items():
        if not isinstance(profile, dict) or profile.get("family") not in families:
            raise ValueError(f"Profile {pid!r} has an unknown policy family")
        max_chars, overlap = profile.get("max_chars"), profile.get("overlap_chars")
        if not isinstance(max_chars, int) or max_chars < 256 or not isinstance(overlap, int) or not 0 <= overlap < max_chars // 2:
            raise ValueError(f"Invalid chunk sizes in profile {pid!r}")
        if not isinstance(profile.get("signals"), list) or not all(isinstance(s, str) and s.strip() for s in profile["signals"]):
            raise ValueError(f"Invalid classification signals in profile {pid!r}")
    for family, requirements in families.items():
        if not isinstance(requirements, list) or not requirements:
            raise ValueError(f"Policy family {family!r} must have requirements")
        seen: set[str] = set()
        for item in requirements:
            name = item if isinstance(item, str) else item.get("category") if isinstance(item, dict) else None
            if name not in categories or name in seen:
                raise ValueError(f"Unknown or duplicate category {name!r} in policy family {family!r}")
            seen.add(name)
            if isinstance(item, dict) and item.get("applicable", True) is False and not item.get("reason"):
                raise ValueError(f"NOT_APPLICABLE needs a documented reason: {family}.{name}")
    for name, category in categories.items():
        if not isinstance(category, dict) or not isinstance(category.get("description"), str) or not isinstance(category.get("material"), bool):
            raise ValueError(f"Invalid category {name!r}")
    return {"profiles": profiles, "policy": policy, "profiles_sha256": profile_hash, "policy_sha256": policy_hash}


def select_profile(contract: dict[str, Any], requested: str | None, filename: str, sample: str) -> tuple[str, dict[str, Any]]:
    profiles = contract["profiles"]
    if requested:
        if requested not in profiles:
            raise ValueError(f"Unknown profile {requested!r}; available: {', '.join(sorted(profiles))}")
        return requested, profiles[requested]
    text = (filename.replace("_", " ").replace("-", " ") + "\n" + sample[:20000]).casefold()
    scores = [(sum(1 for signal in p["signals"] if signal.casefold() in text), name) for name, p in profiles.items()]
    scores.sort(reverse=True)
    if not scores or scores[0][0] == 0 or (len(scores) > 1 and scores[0][0] == scores[1][0]):
        raise ValueError("Document profile is ambiguous; select one explicitly with --profile")
    return scores[0][1], profiles[scores[0][1]]


def requirements_for(contract: dict[str, Any], profile: dict[str, Any]) -> list[dict[str, Any]]:
    policy = contract["policy"]
    requirements = []
    for item in policy["families"][profile["family"]]:
        entry = {"category": item} if isinstance(item, str) else dict(item)
        category = policy["categories"][entry["category"]]
        requirements.append({
            **entry,
            "description": category["description"],
            "material": category["material"],
            "applicable": entry.get("applicable", True),
        })
    return requirements
