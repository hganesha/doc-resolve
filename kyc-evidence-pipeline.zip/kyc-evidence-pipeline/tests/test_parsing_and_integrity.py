from __future__ import annotations

import json
import pymupdf
import pytest

from kyc_pipeline.chunking import build_chunks
from kyc_pipeline.config import load_contract, requirements_for, select_profile
from kyc_pipeline.evidence import verify_candidates
from kyc_pipeline.extraction import rules_extract
from kyc_pipeline.parsing import parse_file
from kyc_pipeline.reconciliation import reconcile
from kyc_pipeline.util import date_interval, temporal_overlap


def contract_for(profile_id: str):
    c = load_contract()
    p = c["profiles"][profile_id]
    return c, p, requirements_for(c, p)


def test_pdf_coordinates_and_blank_page_are_reported(tmp_path):
    p = tmp_path / "sample.pdf"
    pdf = pymupdf.open()
    page = pdf.new_page()
    page.insert_text((72, 72), "Aster Holdings Ltd owns 65% of Birch Ltd.")
    pdf.new_page()
    pdf.save(str(p))
    pdf.close()
    doc, segments, issues = parse_file(str(p))
    assert doc["page_count"] == 2
    assert any(s["page"] == 1 and s["bbox"] and "65%" in s["text"] for s in segments)
    assert any(i["code"] == "PDF_PAGE_TEXT_INSUFFICIENT" and i["page"] == 2 for i in issues)


def test_html_inline_text_table_and_complex_table_warning(tmp_path):
    p = tmp_path / "article.html"
    p.write_text('''<html><body><h1>Annual Report</h1><div><span>Aster Holdings Ltd</span> owns 65% of Birch Ltd.</div>
<table><tr><th colspan="2">Financials</th></tr><tr><td>Revenue</td><td>200</td></tr></table>
<script>IGNORED MALICIOUS SCRIPT</script></body></html>''')
    _, segments, issues = parse_file(str(p))
    assert any(s["text"] == "Aster Holdings Ltd owns 65% of Birch Ltd." for s in segments)
    assert any(s["kind"] == "table" and "Financials" in s["text"] for s in segments)
    assert all("MALICIOUS SCRIPT" not in s["text"] for s in segments)
    assert any(i["code"] == "HTML_MERGED_TABLE_CELLS" for i in issues)


def test_whole_document_dispersed_facts_with_correct_page_anchors(tmp_path):
    pages = [f"# Other Information {i}\nThis page contains ordinary fictional background information.\n" for i in range(1, 181)]
    pages[11] = "# Corporate Structure\nAs of 2023-12-31, Aster Holdings Ltd owns 65% of Birch Ltd.\n"
    pages[46] = "# Control\nCedar Group Ltd has contractual voting rights over Birch Ltd as of 2023-12-31.\n"
    pages[102] = "# Legal\nBirch Ltd is subject to a regulatory investigation as of 2024-10-15.\n"
    pages[160] = "# Subsequent Events\nAster Holdings Ltd disposed of part of its interest in Birch Ltd on 2024-02-15.\n"
    p = tmp_path / "large_report.txt"
    p.write_text("\f".join(pages))
    doc, segments, issues = parse_file(str(p))
    _, profile, reqs = contract_for("financial_annual_report")
    chunks, _, warnings = build_chunks(segments, profile)
    logs = [{"chunk_id": c["chunk_id"], "status": "OK", "method": "rules", "candidates": rules_extract(c, reqs)} for c in chunks]
    evidence, facts, support_issues, logs = verify_candidates(doc, segments, chunks, logs, reqs, None, False)
    assert not issues and not warnings and not support_issues
    assert len(facts) == 4
    ev_by_id = {e["evidence_id"]: e for e in evidence}
    pages_by_predicate = {f["predicate"]: ev_by_id[f["evidence_ids"][0]]["page"] for f in facts}
    assert pages_by_predicate == {"owns_equity_in": 12, "has_voting_rights_over": 47, "subject_to_regulatory_investigation": 103, "disposed_interest_in": 161}
    _, recon_issues = reconcile(doc, facts, [], [])
    assert any(i["code"] == "STALE_OWNERSHIP_AFTER_DISPOSAL" for i in recon_issues)


def test_hallucinated_quote_is_rejected_not_turned_into_evidence(tmp_path):
    p = tmp_path / "source.txt"
    p.write_text("# Ownership\nAster Holdings Ltd owns 65% of Birch Ltd.\n")
    doc, segments, _ = parse_file(str(p))
    _, profile, reqs = contract_for("ownership_control")
    chunks, _, _ = build_chunks(segments, profile)
    chunk = next(c for c in chunks if "65%" in c["text"])
    bad = {"category": "ownership", "subject": "Aster Holdings Ltd", "predicate": "owns_equity_in", "object": "Birch Ltd", "value": 99, "unit": "percent", "source_quote": "Aster Holdings Ltd owns 99% of Birch Ltd."}
    logs = [{"chunk_id": chunk["chunk_id"], "status": "OK", "method": "openai", "candidates": [bad]}]
    evidence, facts, _, updated = verify_candidates(doc, segments, chunks, logs, reqs, None, False)
    assert evidence == [] and facts == []
    assert updated[0]["status"] == "ERROR"
    assert "citation" in updated[0]["error"]


def test_literals_do_not_make_up_semantic_verification(tmp_path):
    p = tmp_path / "source.txt"
    p.write_text("Aster Holdings Ltd owns 65% of Birch Ltd.\n")
    doc, segments, _ = parse_file(str(p))
    _, profile, reqs = contract_for("ownership_control")
    chunks, _, _ = build_chunks(segments, profile)
    chunk = chunks[0]
    candidate = {"category": "ownership", "subject": "Aster Holdings Ltd", "predicate": "owns_equity_in", "object": "Birch Ltd", "value": 45, "unit": "percent", "source_quote": chunk["text"]}
    logs = [{"chunk_id": chunk["chunk_id"], "status": "OK", "method": "openai", "candidates": [candidate]}]
    _, facts, issues, _ = verify_candidates(doc, segments, chunks, logs, reqs, None, False)
    assert facts[0]["verification_status"] == "PENDING_HUMAN"
    assert facts[0]["source_support"]["literal_checks"]["value_literal_present"] is False
    assert issues[0]["code"] == "CLAIM_LITERAL_SUPPORT_INCOMPLETE"


def test_year_level_temporal_uncertainty_and_no_false_identity_merge():
    assert temporal_overlap("2024", "2024-12-31")
    assert not temporal_overlap("2023", "2024")
    assert temporal_overlap(None, "2024")
    with pytest.raises(ValueError):
        date_interval("2024-13-01")


def test_auto_profile_fails_closed_when_ambiguous():
    contract = load_contract()
    with pytest.raises(ValueError, match="ambiguous"):
        select_profile(contract, None, "unknown.txt", "An unlabeled document")


def test_scanned_pdf_causes_extraction_failed_coverage(cli, paths):
    p = paths["tmp"] / "scan.pdf"
    pdf = pymupdf.open()
    pdf.new_page()
    pdf.save(str(p))
    pdf.close()
    start = cli("ingest", p, "--case-id", "scan", "--profile", "financial_annual_report", "--db", paths["db"], "--checkpoint-db", paths["cp"])
    assert start["status"] == "PAUSED_FOR_REVIEW"
    assert any(i["code"] == "PARSE_OR_STRUCTURE_INCOMPLETE" for i in start["review_request"]["issues"])
    response = {"reviewer_id": "TEST", "decisions": [{"issue_id": i["issue_id"], "action": "defer", "reason": "OCR and review are needed."} for i in start["review_request"]["issues"]]}
    decision = paths["tmp"] / "scan-decision.json"
    decision.write_text(json.dumps(response))
    cli("resume", "--run-id", start["run_id"], "--decision", decision, "--db", paths["db"], "--checkpoint-db", paths["cp"])
    package = cli("report", "--case-id", "scan", "--db", paths["db"])
    assert all(c["status"] == "EXTRACTION_FAILED" for c in package["coverage"])
