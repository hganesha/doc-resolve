# KYC evidence preparation pipeline

A runnable **Python + LangGraph proof of concept** for preparing auditable KYC/KYB evidence from documents. It combines structure-aware parent/child chunks, document-wide extraction, exact source pointers, a coverage ledger, basic reconciliation, and a checkpointed human-review gate. It is **not a KYC decision engine** and does not establish that a document or case is complete.

> **Sensitive-data warning:** This project stores document text, extracted facts, review decisions, model outputs, and graph checkpoints in **unencrypted local SQLite files**. The original source file is not copied into the evidence store: retain it separately in an approved, immutable evidence repository. Use only synthetic data until appropriate security, retention, access-control, and model-provider controls have been established.

## What is implemented

```text
                                 ┌─ Query path: BM25 / optional embeddings
                                 │               → child hits + parent context
Document → parse + classify → structure/chunk → index
                                                  ↓
                 Whole-document extraction → source-pointer checks
                                                  ↓
                      reconcile against current case → human interrupt if needed
                                                  ↓
                         coverage ledger → transactional canonical evidence store
```

- **Two distinct paths:** retrieval searches the source chunks; extraction independently processes every parsed chunk against the applicable document-family contract. Retrieval results are not treated as proof of completeness.
- **Ten declarative document-family profiles** and a separate illustrative policy/coverage contract. Three starter examples cover a financial report, registry extract, and adverse-media article; the remaining profiles are templates, not fully tuned specialist extractors.
- **Structure and provenance:** sections, paragraphs, table rows and headers, linked Markdown footnotes, page numbers and PDF block/table coordinates where available. Quotes carry a document SHA-256, normalized segment SHA-256, exact Unicode-code-point offsets, source locator, and representation type. Table reconstruction is identified as such.
- **Atomic facts, evidence and findings** are separate. Every extracted claim remains `PENDING_HUMAN`; exact quote matching and optional model source-support checks do not establish external truth or legal identity.
- **Coverage and gaps:** section inventory, processed/failed chunks, category status and explicit unresolved issues. Available statuses are `FOUND`, `NOT_FOUND_AFTER_REVIEW`, `NOT_APPLICABLE`, `NOT_REVIEWED`, `EXTRACTION_FAILED`, and `CONFLICTED`. A negative automated review is not proof of absence.
- **Conservative reconciliation:** normalized-text entity matching, same/overlapping-date ownership conflicts, duplicate-like source claims, and older ownership snapshots followed by disposals. Different dated stakes are not automatically contradictions. No current percentage is inferred from a partial disposal.
- **Human intervention:** a LangGraph interrupt includes the issues, related facts and source quotes. Review decisions are persisted with self-reported reviewer attribution. Deferring an issue does not resolve it; resolving a possible conflict preserves all source claims and does not automatically verify either claim.
- **Checkpoints and retry:** graph stages are checkpointed in SQLite; extraction results are cached per chunk. A retry of identical source bytes and the same configuration reuses successful units and retries failed ones. An optimistic case-revision check prevents persisting conclusions based on a case that changed during processing or review.
- **Offline by default:** BM25 retrieval and intentionally narrow rule extraction require no API key and make no network calls. Optional OpenAI-compatible JSON extraction, material-fact source-support checks and embeddings require explicit data-sharing opt-in.

## Requirements and quick start

Python 3.11 or newer. Tested with Python 3.13. The example files and reviewer identities are entirely fictional.

```bash
python -m venv .venv
source .venv/bin/activate                    # Windows: .venv\Scripts\activate
python -m pip install -e '.[test]'
pytest
./scripts/run_demo.sh
python scripts/evaluate.py
```

The demo creates a unique synthetic case under `results/`, deliberately **defers** a stale-ownership issue, exports `results/evidence-package.json`, and writes a retrieval result to `results/query.json`. The output remains `REVIEW_REQUIRED`.

`evaluate.py` checks two tiny, exhaustively labeled synthetic documents: one with facts on separate pages and a table/footnote, and another with contradictory ownership figures. It reports fact-level recall, an unsupported-claim rate against that narrow gold set, review-trigger detection, and table/footnote linkage. These results are a plumbing check, **not a performance estimate for real documents**. The tests additionally generate a 180-page synthetic document with evidence on pages 12, 47, 103 and 161.

## Manual workflow

Unless overridden, the evidence database is `kyc_data/evidence.sqlite` and the LangGraph checkpoint database is `kyc_data/checkpoints.sqlite`. The files are created with owner-only permissions where supported, but **they are not encrypted**. Keep both databases together: the evidence DB alone cannot resume a paused graph.

### 1. Inspect the available profiles

```bash
kyc-pipeline profiles
```

Auto-classification looks for simple profile signals and fails closed on an ambiguous/no-signal document. Prefer an explicitly selected profile:

```bash
kyc-pipeline ingest examples/synthetic_annual_report.txt \
  --case-id acme-demo --profile financial_annual_report > pause.json
```

The synthetic annual report pauses on `STALE_OWNERSHIP_AFTER_DISPOSAL`: the reported 65% stake is older than the disposal and no later stake is provided. `pause.json` includes a `run_id`, the issue IDs, related facts and their source quotes. A run without a material issue goes directly to `PERSISTED`, but can still be `REVIEW_REQUIRED` because required categories have not been adequately reviewed.

### 2. Review and resume

In a real workflow an authorized analyst would inspect the original documents, the citations and policy before recording a decision. For the **fictional demo only**, this command writes a deferral for each issue:

```bash
python - <<'PY'
import json
p = json.load(open('pause.json'))
assert p['status'] == 'PAUSED_FOR_REVIEW'
decision = {
    'reviewer_id': 'SYNTHETIC_DEMO_ONLY',
    'decisions': [
        {'issue_id': i['issue_id'], 'action': 'defer',
         'reason': 'Synthetic example: obtain a current ownership record.'}
        for i in p['review_request']['issues']
    ]
}
with open('decision.json', 'w') as f:
    json.dump(decision, f, indent=2)
PY
RUN_ID=$(python -c "import json; print(json.load(open('pause.json'))['run_id'])")
kyc-pipeline resume --run-id "$RUN_ID" --decision decision.json
```

Each pending high-severity issue needs exactly one decision. `defer` leaves it open. For a `POSSIBLE_OWNERSHIP_CONFLICT`, the request also permits `resolve` with a nonempty reason and exactly one `selected_fact_ids` value copied from that issue. All conflicting claims remain stored; reviewer identity is **not authenticated** in this POC. Parse failures, unsupported source claims and stale ownership can only be deferred here; obtain better evidence or reprocess an improved source rather than declaring them resolved without support.

Check a paused run without consuming it:

```bash
kyc-pipeline status --run-id "$RUN_ID"
```

### 3. Export, search, and inspect citations

```bash
kyc-pipeline report --case-id acme-demo --output evidence-package.json
kyc-pipeline query --case-id acme-demo --query 'Who controls Birch Ltd?' --top-k 5
# Copy a segment_id from an evidence record:
kyc-pipeline segment --case-id acme-demo --segment-id 'seg_...'
```

The package contains documents, run/configuration hashes, evidence, facts, findings, coverage, section inventory, issue/review records and an audit-event list. A `segment` provides the exact normalized text against which an evidence record's `[start:end]` offsets can be checked. For a PDF, inspect the original page and coordinates as well; extracted text and reconstructed tables can differ from the visual source.

Add more documents to the same case by calling `ingest` again with the same case ID. Reconciliation compares current extracted claims across documents using normalized **text only**; it does not prove that names refer to the same legal entity.

### 4. Retry failed units

```bash
kyc-pipeline retry --run-id "$RUN_ID"
```

A retry starts a new run, reuses cached successful extraction chunks when their source, policy, profile, model, endpoint and extraction-cache version match, and retries failed chunks. It re-runs source checking and reconciliation; embeddings are rebuilt if enabled. The source file must still be available and have identical bytes (or supply `--file` pointing to the identical file). For OCR or changed source bytes, use a **new** `ingest` instead. Reprocessing the original document after adding a newer ownership record can reassess a previously deferred stale-ownership finding; review remains necessary.

If another document is committed to a case while a graph is running or paused, the optimistic revision check refuses to persist the stale result. Retry the affected run so it reconciles against the new case state.

## Optional model extraction and embeddings

Only use a model endpoint after confirming that sending the specific documents and personal data to it is permitted by your organization's policies and the provider's contractual/security terms. The opt-in applies to local OpenAI-compatible endpoints too.

```bash
export OPENAI_API_KEY='...'
export OPENAI_MODEL='your-model-supporting-json-object-mode'
# Optional; default is https://api.openai.com/v1
export OPENAI_BASE_URL='https://your-approved-openai-compatible-endpoint/v1'
# Optional, only for dense search:
export OPENAI_EMBEDDING_MODEL='your-embedding-model'

kyc-pipeline ingest examples/synthetic_annual_report.txt \
  --case-id model-demo --profile financial_annual_report \
  --extractor openai --embeddings openai --verify-material \
  --allow-remote-sensitive-data
```

`--verify-material` makes an additional model call for each material candidate claim to check whether its **cited text** supports it. It does not check external truth, sanctions status or identity. A `SUPPORTED` verdict is still provisional; `UNSUPPORTED`, `UNCERTAIN`, errors, or missing literal fields create review issues. Model output must match a strict JSON schema and cite exact source text; rejected or truncated output marks extraction as failed. Document content is treated as untrusted data, but prompt-injection resistance is not guaranteed.

For hybrid query-time retrieval, the question is also sent to the configured embedding endpoint:

```bash
kyc-pipeline query --case-id model-demo --query 'Who controls Birch Ltd?' \
  --embeddings openai --allow-remote-sensitive-data
```

Use the same embedding model as indexing. Missing, failed, incompatible or mismatched embeddings fall back to lexical search with a warning. The endpoint must implement OpenAI-style `/chat/completions` with JSON-object mode and/or `/embeddings`; no live provider is needed for the test suite. A retry that uses a model requires `--allow-remote-sensitive-data` again and the same endpoint. Model providers can change behavior under a stable model name; cached responses are not an independent validation.

## Profiles and policy

`src/kyc_pipeline/configs/document_profiles.yaml` defines family, classification signals and chunk sizes; `src/kyc_pipeline/configs/kyc_policy.yaml` defines illustrative category guidance and materiality per family. They are separate because document processing and bank policy are different concerns. Replace them with approved configurations, for example:

```bash
kyc-pipeline ingest my-report.pdf --case-id case-42 \
  --profile financial_annual_report \
  --profiles-file approved-profiles.yaml --policy-file approved-policy.yaml
```

For a specific family, an explicit policy requirement may be written as `{category: ownership, applicable: false, reason: 'documented rationale'}`. `NOT_APPLICABLE` requires that reason; it is not inferred from missing evidence. The included policy is **illustrative only**, not a regulatory rule or a bank-approved policy.

The strategy names in the ten profiles are configuration labels for the intended document treatment; this POC uses one shared generic structure/table engine with profile-specific window sizes. It does not yet implement distinct clause-, transaction-, or chronology-aware parsers for every profile, and field groupings depend on the parsed record/paragraph boundaries.

The local rules intentionally recognize only a small set of literal patterns: simple registry fields, ownership percentages, contractual voting rights, a regulatory-investigation phrase, a disposal phrase, simple revenue tables, and a basic allegation phrase. They do **not** perform an exhaustive semantic review. A category with no matched rule is `NOT_REVIEWED`, not `NOT_FOUND_AFTER_REVIEW`. A `FOUND` record only means a candidate was found; it does not imply the category is exhaustive or the fact is verified.

## Input formats and known gaps

- UTF-8 `.txt`/`.md`, static `.html`, `.csv`, and text-based `.pdf` up to 50 MiB. TXT form feeds create supplied page anchors; HTML/CSV do not have invented page numbers. No URL fetching, DOCX/Excel parsing, or JavaScript execution.
- PDF text blocks, coordinates and detected tables use PyMuPDF. Empty/image-heavy pages and some table problems are flagged, but OCR is **not** implemented. Not every embedded image, complex/merged table, cross-page table, multi-column order, footnote or cross-reference will be detected. HTML scripts, images, embedded sources, merged cells and orphan text are flagged when recognized. Treat parsing issues as coverage failures and visually review original sources.
- Inline Markdown footnote markers are linked to matching footnotes in the **same parsed section**. General footnote resolution, complex table semantics, document amendments, and semantic cross-reference navigation are not complete.
- The pipeline does not perform authoritative registry checks, live sanctions/PEP screening, identity verification, beneficial-ownership graph calculations, source-of-funds verification, complete contradiction resolution, or policy-driven customer acceptance decisions. Allegations are not findings of guilt.
- Literal quote and number checks are not semantic validation. Model source-support checks can also be wrong or manipulated. Automated `NOT_FOUND_AFTER_REVIEW` means only that the parsed chunks received a successful model pass; it is not proof of absence.
- SQLite is suitable only for a single-host POC. The evidence store and graph checkpoints are separate databases, so their commits are not one distributed transaction; writes are designed to be idempotent and use a case revision check. There is no authentication, authorization, encryption, secrets manager, immutable/WORM audit log, redaction, retention/deletion workflow, scalable job queue, or production observability. Human reviewer IDs are self-reported. Add these before handling real KYC information.
- All document content in the evidence database, extraction cache, checkpoint database, exports, and review files is sensitive. Control access to all copies, including SQLite WAL/SHM files and backups. External API calls send source text when opted in; configure provider logging and retention appropriately.

## Project layout

```text
src/kyc_pipeline/
  configs/              # processing profiles and separate illustrative policy
  parsing.py            # format adapters and parse-gap tracking
  chunking.py           # sections, child windows, tables, footnote context
  extraction.py         # local rules and opt-in OpenAI-compatible provider
  evidence.py           # exact spans, atomic claims, material source checks
  reconciliation.py     # conservative claims, date and conflict checks
  coverage.py           # coverage ledger and section manifest
  graph.py              # LangGraph orchestration and human interrupt
  store.py              # local SQLite records, cache, audit and case revisions
  retrieval.py          # BM25 + optional embedding search, parent context
  cli.py                # ingest, status, resume, retry, report, query, segment
examples/               # fictional fixtures and gold labels
scripts/                # runnable demo and tiny labeled evaluation
tests/                  # unit, graph, provider-mock and CLI integration tests
```
