from __future__ import annotations

import re
from collections import defaultdict
from typing import Any
from .util import stable_id


def _windows(text: str, maximum: int, overlap: int) -> list[tuple[int, int]]:
    if not text:
        return []
    spans = []
    start = 0
    while start < len(text):
        end = min(len(text), start + maximum)
        if end < len(text):
            last_space = text.rfind(" ", start + maximum // 2, end)
            last_line = text.rfind("\n", start + maximum // 2, end)
            boundary = max(last_space, last_line)
            if boundary > start:
                end = boundary + 1
        spans.append((start, end))
        if end >= len(text):
            break
        start = max(start + 1, end - overlap)
    return spans


def _is_separator(line: str) -> bool:
    return bool(re.fullmatch(r"[\s|:\-]+", line))


def build_chunks(segments: list[dict], profile: dict[str, Any]) -> tuple[list[dict], list[dict], list[dict]]:
    maximum, overlap = profile["max_chars"], profile["overlap_chars"]
    chunks: list[dict] = []
    warnings: list[dict] = []
    notes_by_section: dict[str, list[dict]] = defaultdict(list)
    sections: dict[str, dict] = {}
    for seg in segments:
        if seg["kind"] == "footnote":
            notes_by_section[seg["section_id"]].append(seg)
        sec = sections.setdefault(seg["section_id"], {"section_id": seg["section_id"], "section_path": seg["section_path"], "segment_count": 0, "chunk_count": 0, "pages": []})
        sec["segment_count"] += 1
        if seg["page"] is not None and seg["page"] not in sec["pages"]:
            sec["pages"].append(seg["page"])
    for seg in segments:
        text = seg["text"]
        table_header = None
        spans = []
        if seg["kind"] == "table":
            lines = list(re.finditer(r"[^\n]+", text))
            content_lines = [m for m in lines if not _is_separator(m.group())]
            if content_lines:
                table_header = content_lines[0].group()
                # Header is indexed too; rows retain the exact header as contextual evidence.
                for match in content_lines:
                    line = match.group()
                    if len(line) > maximum * 4:
                        warnings.append({"code": "OVERSIZED_TABLE_ROW_SPLIT", "message": "A table row exceeded the size limit and was split; review the complete table manually.", "page": seg["page"], "segment_id": seg["segment_id"]})
                        spans.extend((match.start() + s, match.start() + e) for s, e in _windows(line, maximum * 4, overlap))
                    else:
                        spans.append((match.start(), match.end()))
        else:
            spans = _windows(text, maximum, overlap)
        for start, end in spans:
            body = text[start:end]
            # Footnote text is context, not silently incorporated into the quoted source span.
            refs = set(re.findall(r"\[\^?([\w-]+)\]", body))
            related_notes = []
            for note in notes_by_section.get(seg["section_id"], []):
                m = re.match(r"\[\^?([^\]]+)\]:", note["text"])
                if m and m.group(1) in refs:
                    related_notes.append({"segment_id": note["segment_id"], "locator": note["locator"], "text": note["text"]})
            chunk = {
                "chunk_id": stable_id("chk", seg["document_id"], seg["segment_id"], start, end),
                "document_id": seg["document_id"], "segment_id": seg["segment_id"],
                "section_id": seg["section_id"], "section_path": seg["section_path"],
                "kind": seg["kind"], "page": seg["page"], "locator": seg["locator"],
                "start": start, "end": end, "text": body,
                "table_header": table_header, "footnote_context": related_notes,
                "embedding": None, "embedding_model": None,
            }
            chunks.append(chunk)
            sections[seg["section_id"]]["chunk_count"] += 1
    return chunks, list(sections.values()), warnings
