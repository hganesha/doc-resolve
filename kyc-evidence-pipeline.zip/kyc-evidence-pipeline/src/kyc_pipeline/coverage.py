from __future__ import annotations

from typing import Any


def compute_coverage(requirements: list[dict], chunks: list[dict], extraction_log: list[dict], facts: list[dict], issues: list[dict], extraction_method: str) -> list[dict]:
    total = len(chunks)
    processed = sum(log["status"] == "OK" for log in extraction_log)
    failed = sum(log["status"] != "OK" for log in extraction_log)
    open_issues = [i for i in issues if i["status"] == "OPEN"]
    records = []
    for req in requirements:
        category = req["category"]
        category_facts = [f for f in facts if f["category"] == category]
        relevant = [i for i in open_issues if "*" in i["categories"] or category in i["categories"]]
        failures = [i for i in relevant if i["code"] in {"PARSE_OR_STRUCTURE_INCOMPLETE", "EXTRACTION_FAILED", "CLAIM_LITERAL_SUPPORT_INCOMPLETE", "MATERIAL_SEMANTIC_SUPPORT_UNCERTAIN", "MATERIAL_SEMANTIC_VERIFICATION_FAILED"}]
        conflicts = [i for i in relevant if i["code"] == "POSSIBLE_OWNERSHIP_CONFLICT"]
        if not req["applicable"]:
            status = "NOT_APPLICABLE"
        elif failed or failures:
            status = "EXTRACTION_FAILED"
        elif conflicts:
            status = "CONFLICTED"
        elif category_facts:
            status = "FOUND"
        elif extraction_method == "openai" and total > 0 and processed == total:
            status = "NOT_FOUND_AFTER_REVIEW"
        else:
            status = "NOT_REVIEWED"
        records.append({
            "category": category, "description": req["description"], "material": req["material"],
            "status": status, "applicability_reason": req.get("reason"),
            "fact_count": len(category_facts), "chunks_total": total, "chunks_processed": processed,
            "chunks_failed": failed, "open_issue_ids": [i["issue_id"] for i in relevant],
            "review_method": "automated_model_pass" if extraction_method == "openai" else "limited_pattern_rules",
            "completeness_asserted": False,
            "note": "Not found after automated review is not proof of absence." if status == "NOT_FOUND_AFTER_REVIEW" else ("Rules are illustrative and do not provide exhaustive semantic review." if extraction_method == "rules" else "Facts remain provisional until appropriately verified."),
        })
    return records


def complete_section_inventory(sections: list[dict], chunks: list[dict], logs: list[dict]) -> list[dict]:
    by_chunk = {log["chunk_id"]: log for log in logs}
    result = []
    for section in sections:
        ids = [c["chunk_id"] for c in chunks if c["section_id"] == section["section_id"]]
        result.append({**section, "chunks_processed": sum(by_chunk.get(i, {}).get("status") == "OK" for i in ids), "chunks_failed": sum(by_chunk.get(i, {}).get("status") != "OK" for i in ids)})
    return result
