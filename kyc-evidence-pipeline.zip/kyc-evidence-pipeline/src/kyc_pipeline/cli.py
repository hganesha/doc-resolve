from __future__ import annotations

import argparse
import json
import os
import re
import sys
import uuid
from pathlib import Path
from typing import Any

from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.types import Command

from .config import load_contract, requirements_for
from .extraction import OpenAICompatible
from .graph import build_graph, validate_review_response
from .retrieval import search_chunks
from .store import EvidenceStore
from .util import digest, json_text, utc_now

DEFAULT_DB = "kyc_data/evidence.sqlite"
DEFAULT_CHECKPOINT = "kyc_data/checkpoints.sqlite"


def _case(value: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", value):
        raise argparse.ArgumentTypeError("case ID must be 1–80 letters, digits, dots, underscores, or hyphens")
    return value


def _db_options(parser: argparse.ArgumentParser, *, checkpoint: bool = False) -> None:
    parser.add_argument("--db", default=DEFAULT_DB, help=f"Evidence SQLite file (default: {DEFAULT_DB})")
    if checkpoint:
        parser.add_argument("--checkpoint-db", default=DEFAULT_CHECKPOINT, help=f"LangGraph SQLite checkpoints (default: {DEFAULT_CHECKPOINT})")


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="kyc-pipeline", description="Auditable KYC evidence preparation proof of concept; not a KYC decision engine")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("profiles", help="List declarative processing profiles and illustrative coverage categories")
    p.add_argument("--profiles-file")
    p.add_argument("--policy-file")
    p = sub.add_parser("ingest", help="Parse and prepare one document")
    p.add_argument("file")
    p.add_argument("--case-id", type=_case, required=True)
    p.add_argument("--profile", help="Explicit document profile; automatic selection fails closed if ambiguous")
    p.add_argument("--extractor", choices=["rules", "openai"], default="rules")
    p.add_argument("--embeddings", choices=["lexical", "openai"], default="lexical")
    p.add_argument("--verify-material", action="store_true", help="Run an additional model source-support check for material facts")
    p.add_argument("--allow-remote-sensitive-data", action="store_true", help="Explicitly permit sending document content to the configured API endpoint")
    p.add_argument("--model", default=os.environ.get("OPENAI_MODEL", "gpt-4.1-mini"))
    p.add_argument("--embedding-model", default=os.environ.get("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small"))
    p.add_argument("--profiles-file")
    p.add_argument("--policy-file")
    _db_options(p, checkpoint=True)
    p = sub.add_parser("resume", help="Resume an interrupted run using a human review JSON file")
    p.add_argument("--run-id", required=True)
    p.add_argument("--decision", required=True)
    _db_options(p, checkpoint=True)
    p = sub.add_parser("retry", help="Create a new run, reusing successful extraction units and retrying failed units")
    p.add_argument("--run-id", required=True, help="Previous run ID")
    p.add_argument("--file", help="Optional replacement path to identical source bytes")
    p.add_argument("--allow-remote-sensitive-data", action="store_true", help="Re-confirm permission for any model calls")
    _db_options(p, checkpoint=True)
    p = sub.add_parser("status", help="Inspect run status and any human-review request")
    p.add_argument("--run-id", required=True)
    _db_options(p, checkpoint=True)
    p = sub.add_parser("report", help="Export the canonical case evidence package")
    p.add_argument("--case-id", type=_case, required=True)
    p.add_argument("--output", help="Write JSON to this file instead of stdout")
    _db_options(p)
    p = sub.add_parser("query", help="Retrieve relevant child chunks with parent-section context")
    p.add_argument("--case-id", type=_case, required=True)
    p.add_argument("--query", required=True)
    p.add_argument("--top-k", type=int, default=5)
    p.add_argument("--embeddings", choices=["lexical", "openai"], default="lexical")
    p.add_argument("--embedding-model", default=os.environ.get("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small"))
    p.add_argument("--allow-remote-sensitive-data", action="store_true")
    _db_options(p)
    p = sub.add_parser("segment", help="Inspect the normalized source segment behind an evidence offset")
    p.add_argument("--case-id", type=_case, required=True)
    p.add_argument("--segment-id", required=True)
    _db_options(p)
    return parser


def _checkpoint_path(path: str) -> str:
    p = Path(path).expanduser().resolve()
    p.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(p, os.O_CREAT | os.O_RDWR, 0o600)
    os.close(fd)
    try:
        os.chmod(p, 0o600)
    except OSError:
        pass
    return str(p)


def _new_run_id() -> str:
    return "run_" + uuid.uuid4().hex


def _preflight_remote(extractor: str, embeddings: str, verify_material: bool, allow_remote: bool, model: str, embedding_model: str) -> None:
    if verify_material and extractor != "openai":
        raise ValueError("--verify-material requires --extractor openai")
    if extractor == "openai" or embeddings == "openai":
        provider = OpenAICompatible(allow_remote=allow_remote, model=model, embedding_model=embedding_model)
        provider.client.close()


def _interrupt_value(result: dict) -> dict | None:
    interrupts = result.get("__interrupt__", ())
    return interrupts[0].value if interrupts else None


def _snapshot_request(snapshot: Any) -> dict | None:
    for task in snapshot.tasks:
        for item in task.interrupts:
            return item.value
    return None


def _drive(graph: Any, store: EvidenceStore, run_id: str, case_id: str, input_value: Any) -> dict:
    config = {"configurable": {"thread_id": run_id}}
    try:
        result = graph.invoke(input_value, config=config)
    except Exception as exc:
        safe = str(exc) if isinstance(exc, ValueError) else f"Pipeline failed ({type(exc).__name__}); see local diagnostics."
        store.set_run_status(run_id, "FAILED", error=safe)
        raise ValueError(safe) from exc
    request = _interrupt_value(result)
    if request:
        store.set_run_status(run_id, "REVIEW_REQUIRED")
        return {"status": "PAUSED_FOR_REVIEW", "run_id": run_id, "case_id": case_id, "review_request": request, "next_step": "Submit a review decision with the resume command, or retry failed extraction units."}
    row = store.get_run(run_id)
    return {"status": "PERSISTED", "run_id": run_id, "case_id": case_id, "run_status": row["status"], "summary": json.loads(row["summary_json"]) if row and row["summary_json"] else None, "next_step": "Export the case with the report command; all facts remain provisional."}


def _write_output(data: dict, output: str | None = None) -> None:
    text = json_text(data, pretty=True) + "\n"
    if output:
        path = Path(output).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    else:
        sys.stdout.write(text)


def execute(args: argparse.Namespace) -> dict:
    if args.command == "profiles":
        contract = load_contract(args.profiles_file, args.policy_file)
        return {"policy_id": contract["policy"]["policy_id"], "profiles": [{"profile_id": pid, **p, "requirements": requirements_for(contract, p)} for pid, p in contract["profiles"].items()], "note": "Profiles and policy are illustrative, not bank-approved policy."}
    store = EvidenceStore(args.db)
    if args.command == "report":
        package = store.export_case(args.case_id)
        if not package["documents"] and not package["pending_runs"] and not package["audit_events"]:
            raise ValueError("Case not found")
        return package
    if args.command == "segment":
        segment = store.get_segment(args.case_id, args.segment_id)
        if not segment:
            raise ValueError("Segment not found in the current case evidence")
        return segment
    if args.command == "query":
        provider = None
        if args.embeddings == "openai":
            provider = OpenAICompatible(allow_remote=args.allow_remote_sensitive_data, embedding_model=args.embedding_model)
        try:
            chunks = store.current_chunks(args.case_id)
            if not chunks:
                raise ValueError("Case has no persisted searchable chunks")
            return search_chunks(chunks, args.query, args.top_k, provider=provider)
        finally:
            if provider:
                provider.client.close()
    checkpoint_path = _checkpoint_path(args.checkpoint_db)
    with SqliteSaver.from_conn_string(checkpoint_path) as saver:
        graph = build_graph(store, saver)
        if args.command == "ingest":
            contract = load_contract(args.profiles_file, args.policy_file)
            _preflight_remote(args.extractor, args.embeddings, args.verify_material, args.allow_remote_sensitive_data, args.model, args.embedding_model)
            run_id = _new_run_id()
            state = {"run_id": run_id, "case_id": args.case_id, "started_at": utc_now(), "doc_path": str(Path(args.file).expanduser().resolve()), "requested_profile": args.profile, "contract": contract, "extractor": args.extractor, "embeddings": args.embeddings, "allow_remote": args.allow_remote_sensitive_data, "verify_material": args.verify_material, "model": args.model, "embedding_model": args.embedding_model, "provider_endpoint_sha256": digest(os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")) if args.extractor == "openai" or args.embeddings == "openai" else None, "retry_from_run": None, "expected_document_sha256": None}
            store.start_run(run_id, args.case_id, state["started_at"])
            return _drive(graph, store, run_id, args.case_id, state)
        row = store.get_run(args.run_id)
        if not row:
            raise ValueError("Run not found")
        config = {"configurable": {"thread_id": args.run_id}}
        snapshot = graph.get_state(config)
        if args.command == "status":
            row["summary"] = json.loads(row.pop("summary_json")) if row.get("summary_json") else None
            return {"run": row, "review_request": _snapshot_request(snapshot)}
        if args.command == "resume":
            if row["status"] != "REVIEW_REQUIRED" or row["finished_at"] is not None or not _snapshot_request(snapshot):
                raise ValueError("Run is not paused at a human-review interrupt")
            try:
                response = json.loads(Path(args.decision).read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                raise ValueError("Decision file must be readable JSON") from None
            validate_review_response(response, snapshot.values["issues"])
            return _drive(graph, store, args.run_id, row["case_id"], Command(resume=response))
        if args.command == "retry":
            prior = snapshot.values
            if not prior or not prior.get("document") or not store.get_extraction_units(args.run_id):
                raise ValueError("Run has no checkpointed document and extraction units to retry")
            path = Path(args.file or prior["doc_path"]).expanduser().resolve()
            if not path.is_file() or digest(path.read_bytes()) != prior["document"]["sha256"]:
                raise ValueError("Retry requires the identical original source bytes; use ingest for changed documents")
            _preflight_remote(prior["extractor"], prior["embeddings"], prior.get("verify_material", False), args.allow_remote_sensitive_data, prior["model"], prior["embedding_model"])
            endpoint_hash = digest(os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")) if prior["extractor"] == "openai" or prior["embeddings"] == "openai" else None
            if endpoint_hash != prior.get("provider_endpoint_sha256"):
                raise ValueError("Retry requires the same provider endpoint; use a fresh ingestion if it changed")
            new_id = _new_run_id()
            state = {"run_id": new_id, "case_id": prior["case_id"], "started_at": utc_now(), "doc_path": str(path), "requested_profile": prior["profile_id"], "contract": prior["contract"], "extractor": prior["extractor"], "embeddings": prior["embeddings"], "allow_remote": args.allow_remote_sensitive_data, "verify_material": prior.get("verify_material", False), "model": prior["model"], "embedding_model": prior["embedding_model"], "provider_endpoint_sha256": endpoint_hash, "retry_from_run": args.run_id, "expected_document_sha256": prior["document"]["sha256"]}
            store.start_run(new_id, state["case_id"], state["started_at"])
            if row["finished_at"] is None and row["status"] in {"REVIEW_REQUIRED", "FAILED", "PROCESSING"}:
                store.set_run_status(args.run_id, "SUPERSEDED")
            return _drive(graph, store, new_id, state["case_id"], state)
    raise ValueError("Unsupported command")


def main(argv: list[str] | None = None) -> int:
    args = make_parser().parse_args(argv)
    try:
        result = execute(args)
        _write_output(result, getattr(args, "output", None))
        return 0
    except (ValueError, OSError) as exc:
        sys.stderr.write(json_text({"status": "ERROR", "message": str(exc)}, pretty=True) + "\n")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
