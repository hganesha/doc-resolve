from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator
from .util import date_interval


class CandidateFact(BaseModel):
    """Model output is untrusted until its citations and basic fields are checked."""
    model_config = ConfigDict(extra="forbid")
    category: str = Field(min_length=1, max_length=80)
    subject: str = Field(min_length=1, max_length=250)
    predicate: str = Field(pattern=r"^[a-z][a-z0-9_]{1,79}$")
    object: str | None = Field(default=None, max_length=250)
    value: float | str | None = None
    unit: str | None = Field(default=None, max_length=80)
    effective_date: str | None = None
    claim_type: Literal["assertion", "reported_statement", "allegation", "finding", "order", "disposition", "denial"] = "reported_statement"
    attribution: str | None = Field(default=None, max_length=250)
    source_quote: str = Field(min_length=1, max_length=1200)
    supporting_quotes: list[str] = Field(default_factory=list, max_length=4)

    @field_validator("effective_date")
    @classmethod
    def valid_date(cls, value: str | None) -> str | None:
        if value is not None:
            date_interval(value)
        return value

    @field_validator("subject", "source_quote")
    @classmethod
    def nonblank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("must not be blank")
        return value

    @field_validator("supporting_quotes")
    @classmethod
    def valid_quotes(cls, value: list[str]) -> list[str]:
        if any(not s.strip() or len(s) > 1200 for s in value):
            raise ValueError("supporting quotes must contain 1–1200 characters")
        return value


class ExtractionResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")
    facts: list[CandidateFact] = Field(max_length=100)


class SupportResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")
    support: Literal["SUPPORTED", "UNSUPPORTED", "UNCERTAIN"]
    explanation: str = Field(max_length=500)
