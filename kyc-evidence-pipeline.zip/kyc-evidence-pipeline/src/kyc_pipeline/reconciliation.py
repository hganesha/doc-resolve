from __future__ import annotations

from collections import defaultdict
from itertools import combinations

from .evidence import make_issue
from .util import date_interval, identity_key, json_text, stable_id, temporal_overlap


def _key(fact: dict) -> tuple[str, str]:
    return identity_key(fact.get("subject")), identity_key(fact.get("object"))


def reconcile(document: dict, current_facts: list[dict], previous_facts: list[dict], existing_issues: list[dict]) -> tuple[list[dict], list[dict]]:
    """Conservative textual matching and chronology. No legal-entity resolution or UBO calculation."""
    document_id = document["document_id"]
    current_ids = {f["fact_id"] for f in current_facts}
    all_facts = previous_facts + current_facts
    issues = list(existing_issues)
    findings: list[dict] = []

    # Preserve each source claim; a grouped finding is not proof of independent corroboration.
    groups: dict[tuple, list[dict]] = defaultdict(list)
    for f in all_facts:
        sig = (_key(f), f["predicate"], json_text(f.get("value")), f.get("unit"), f.get("effective_date"), f.get("claim_type"))
        groups[sig].append(f)
    for group in groups.values():
        ids = sorted({f["fact_id"] for f in group})
        if len(ids) >= 2 and any(i in current_ids for i in ids):
            findings.append({"finding_id": stable_id("finding", "similar_claims", ids), "type": "SIMILAR_SOURCE_CLAIMS", "status": "INFORMATIONAL", "category": group[0]["category"], "fact_ids": ids, "description": "Multiple source claims have the same normalized fields; independence and source reliability are not established."})

    ownership = [f for f in all_facts if f["predicate"] == "owns_equity_in" and f.get("object") and isinstance(f.get("value"), (int, float))]
    by_pair: dict[tuple, list[dict]] = defaultdict(list)
    for f in ownership:
        by_pair[_key(f)].append(f)
    for pair, snapshots in by_pair.items():
        if not all(pair):
            continue
        for a, b in combinations(snapshots, 2):
            if not ({a["fact_id"], b["fact_id"]} & current_ids):
                continue
            if a.get("unit") != b.get("unit") or a["value"] == b["value"]:
                continue
            if not temporal_overlap(a.get("effective_date"), b.get("effective_date")):
                continue
            issue = make_issue("POSSIBLE_OWNERSHIP_CONFLICT", "The same text-matched parties have different ownership percentages in overlapping or unknown time periods. This may be a contradiction or an unresolved chronology.", document_id=document_id, categories=["ownership"], fact_ids=[a["fact_id"], b["fact_id"]], details={"dates": sorted([a.get("effective_date") or "unknown", b.get("effective_date") or "unknown"])}, allowed_actions=["resolve", "defer"])
            issues.append(issue)

    sales = [f for f in all_facts if f["predicate"] == "disposed_interest_in" and f.get("object")]
    for sale in sales:
        pair = _key(sale)
        candidates = by_pair.get(pair, [])
        for snapshot in candidates:
            if not ({sale["fact_id"], snapshot["fact_id"]} & current_ids):
                continue
            si, oi = date_interval(sale.get("effective_date")), date_interval(snapshot.get("effective_date"))
            if si and oi and si[0] > oi[1]:
                # A later reported ownership snapshot may address staleness; do not calculate a new stake.
                has_newer = any((date_interval(f.get("effective_date")) or (None, None))[0] is not None and date_interval(f["effective_date"])[0] > si[1] for f in candidates)
                if not has_newer:
                    issues.append(make_issue("STALE_OWNERSHIP_AFTER_DISPOSAL", "An ownership snapshot predates a disposal; the current percentage cannot be inferred from these claims.", document_id=document_id, categories=["ownership", "material_changes"], fact_ids=[sale["fact_id"], snapshot["fact_id"]], details={"ownership_date": snapshot.get("effective_date"), "disposal_date": sale.get("effective_date")}))
            elif not si or not oi:
                issues.append(make_issue("OWNERSHIP_CHRONOLOGY_UNRESOLVED", "A disposal and ownership claim match by text, but missing dates prevent a reliable chronology.", document_id=document_id, categories=["ownership", "material_changes"], fact_ids=[sale["fact_id"], snapshot["fact_id"]]))

    unique = {issue["issue_id"]: issue for issue in issues}
    issues = list(unique.values())
    for issue in issues:
        findings.append({"finding_id": stable_id("finding", issue["issue_id"]), "type": issue["code"], "status": "OPEN", "category": issue["categories"][0] if issue["categories"] else "general", "issue_id": issue["issue_id"], "fact_ids": issue["fact_ids"], "description": issue["message"]})
    return findings, issues
