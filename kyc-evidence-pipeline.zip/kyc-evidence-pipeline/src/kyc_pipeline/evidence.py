from __future__ import annotations

import math
import re
from typing import Any
from pydantic import ValidationError

from .extraction import OpenAICompatible, ProviderError
from .models import CandidateFact
from .util import identity_key, json_text, stable_id


def make_issue(code: str, message: str, *, document_id: str, categories: list[str], severity: str = "high", fact_ids: list[str] | None = None, details: dict | None = None, allowed_actions: list[str] | None = None) -> dict:
    fact_ids = sorted(set(fact_ids or []))
    details = details or {}
    issue_id = stable_id("issue", code, document_id, fact_ids, details)
    return {"issue_id": issue_id, "code": code, "message": message, "document_id": document_id, "categories": categories, "severity": severity, "fact_ids": fact_ids, "details": details, "status": "OPEN", "allowed_actions": allowed_actions or ["defer"]}


def _evidence_record(document: dict, seg: dict, start: int, end: int) -> dict:
    text = seg["text"]
    assert 0 <= start < end <= len(text)
    return {
        "evidence_id": stable_id("ev", document["document_id"], seg["segment_id"], start, end),
        "document_id": document["document_id"], "document_sha256": document["sha256"],
        "segment_id": seg["segment_id"], "normalized_segment_sha256": seg["text_sha256"],
        "quote": text[start:end], "start": start, "end": end,
        "offset_basis": "Unicode code-point offsets in the stored normalized segment, not raw file bytes",
        "locator": seg["locator"], "page": seg["page"], "bbox": seg["bbox"],
        "section_path": seg["section_path"], "representation": seg["representation"],
    }


def _contains_phrase(haystack: str, needle: str) -> bool:
    n = identity_key(needle)
    return bool(n and f" {n} " in f" {identity_key(haystack)} ")


def _numeric_in(value: float, text: str) -> bool:
    if not math.isfinite(value):
        return False
    for token in re.findall(r"(?<![\w.])[+-]?\d[\d,]*(?:\.\d+)?(?![\w.])", text):
        try:
            if math.isclose(float(token.replace(",", "")), value, rel_tol=1e-10, abs_tol=1e-10):
                return True
        except ValueError:
            continue
    return False


def verify_candidates(document: dict, segments: list[dict], chunks: list[dict], extraction_log: list[dict], requirements: list[dict], provider: OpenAICompatible | None, verify_material: bool) -> tuple[list[dict], list[dict], list[dict], list[dict]]:
    """Validate exact source pointers and flag, rather than certify, candidate claims."""
    segment_map = {s["segment_id"]: s for s in segments}
    chunk_map = {c["chunk_id"]: c for c in chunks}
    material = {r["category"]: r["material"] for r in requirements}
    allowed = {r["category"] for r in requirements if r["applicable"]}
    evidences: dict[str, dict] = {}
    facts: dict[str, dict] = {}
    issues: list[dict] = []
    updated_log: list[dict] = []
    for original in extraction_log:
        log = dict(original)
        candidates = log.pop("candidates", [])
        chunk = chunk_map[log["chunk_id"]]
        seg = segment_map[chunk["segment_id"]]
        if log["status"] != "OK":
            updated_log.append(log)
            continue
        for raw in candidates:
            try:
                c = CandidateFact.model_validate(raw)
                if c.category not in allowed:
                    raise ValueError("category outside coverage contract")
                if isinstance(c.value, float) and not math.isfinite(c.value):
                    raise ValueError("non-finite number")
            except (ValidationError, ValueError):
                log["status"] = "ERROR"
                log["error"] = "Candidate did not pass schema validation"
                continue
            quote_offset = chunk["text"].find(c.source_quote)
            supporting_offsets = [seg["text"].find(q) for q in c.supporting_quotes]
            if quote_offset < 0 or any(x < 0 for x in supporting_offsets):
                log["status"] = "ERROR"
                log["error"] = "Candidate citation did not match the normalized source"
                continue
            start = chunk["start"] + quote_offset
            spans = [(start, start + len(c.source_quote))] + [(x, x + len(q)) for x, q in zip(supporting_offsets, c.supporting_quotes)]
            evs = [_evidence_record(document, seg, a, b) for a, b in spans]
            evidence_roles = [{"evidence_id": evs[0]["evidence_id"], "role": "primary_quote"}]
            evidence_roles.extend({"evidence_id": ev["evidence_id"], "role": "supporting_quote"} for ev in evs[1:])
            # A visible footnote marker is an explicit structural link, not an inference
            # that the qualification has been semantically incorporated into the claim.
            for note_ref in chunk.get("footnote_context", []):
                note_seg = segment_map.get(note_ref["segment_id"])
                if note_seg and note_seg["text"]:
                    note_ev = _evidence_record(document, note_seg, 0, len(note_seg["text"]))
                    if all(existing["evidence_id"] != note_ev["evidence_id"] for existing in evs):
                        evs.append(note_ev)
                        evidence_roles.append({"evidence_id": note_ev["evidence_id"], "role": "referenced_footnote"})
            for ev in evs:
                evidences[ev["evidence_id"]] = ev
            fields = c.model_dump(exclude={"source_quote", "supporting_quotes"})
            fact_id = stable_id("fact", document["document_id"], fields, [e["evidence_id"] for e in evs])
            if fact_id in facts:
                continue
            combined_quote = "\n".join(e["quote"] for e in evs)
            checks: dict[str, bool | None] = {
                "exact_quote_match": True,
                "subject_literal_present": _contains_phrase(combined_quote, c.subject) if c.subject != "UNRESOLVED_REGISTRY_SUBJECT" else False,
                "object_literal_present": _contains_phrase(combined_quote, c.object) if c.object else None,
                "value_literal_present": _numeric_in(c.value, combined_quote) if isinstance(c.value, (int, float)) else (_contains_phrase(combined_quote, c.value) if isinstance(c.value, str) else None),
                "date_literal_present": c.effective_date in combined_quote if c.effective_date else None,
            }
            fact = {
                "fact_id": fact_id, "document_id": document["document_id"], **fields,
                "evidence_ids": [e["evidence_id"] for e in evs], "evidence_roles": evidence_roles,
                "extractor": log["method"],
                "verification_status": "PENDING_HUMAN",
                "source_support": {"quote_match": "EXACT_NORMALIZED_TEXT_MATCH", "literal_checks": checks, "semantic_check": "NOT_REQUESTED"},
                "entity_resolution": "TEXT_MATCH_ONLY" if c.subject != "UNRESOLVED_REGISTRY_SUBJECT" else "UNRESOLVED",
            }
            false_checks = [k for k, v in checks.items() if v is False]
            if false_checks:
                issues.append(make_issue("CLAIM_LITERAL_SUPPORT_INCOMPLETE", "A claim contains a subject, object, value, or date not literally present in its cited quotes; context or human review is required.", document_id=document["document_id"], categories=[c.category], severity="high" if material.get(c.category) else "medium", fact_ids=[fact_id], details={"failed_checks": false_checks}))
            if verify_material and material.get(c.category):
                if provider is None:
                    raise ValueError("Semantic verification requires the OpenAI-compatible extractor")
                try:
                    result = provider.verify_support(fact, evs)
                    fact["source_support"]["semantic_check"] = result["support"]
                    fact["source_support"]["semantic_explanation"] = result["explanation"]
                    if result["support"] != "SUPPORTED":
                        issues.append(make_issue("MATERIAL_SEMANTIC_SUPPORT_UNCERTAIN", "The model source-support check did not establish support; this does not determine external truth.", document_id=document["document_id"], categories=[c.category], fact_ids=[fact_id], details={"verdict": result["support"]}))
                except ProviderError:
                    fact["source_support"]["semantic_check"] = "VERIFICATION_FAILED"
                    issues.append(make_issue("MATERIAL_SEMANTIC_VERIFICATION_FAILED", "Material source-support verification failed and requires review.", document_id=document["document_id"], categories=[c.category], fact_ids=[fact_id]))
            facts[fact_id] = fact
        updated_log.append(log)
    return list(evidences.values()), list(facts.values()), issues, updated_log
