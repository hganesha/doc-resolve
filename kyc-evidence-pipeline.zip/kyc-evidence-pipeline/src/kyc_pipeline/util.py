from __future__ import annotations

import calendar
import hashlib
import json
import re
import unicodedata
from datetime import date, datetime, timezone
from typing import Any


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def json_text(value: Any, *, pretty: bool = False) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2 if pretty else None, separators=None if pretty else (",", ":"))


def digest(value: bytes | str) -> str:
    if isinstance(value, str):
        value = value.encode("utf-8")
    return hashlib.sha256(value).hexdigest()


def stable_id(prefix: str, *parts: Any) -> str:
    return prefix + "_" + digest(json_text(parts))[:24]


def identity_key(name: str | None) -> str:
    """Conservative textual key, NOT legal-entity resolution or an alias match."""
    if not name:
        return ""
    normalized = unicodedata.normalize("NFKC", name).casefold()
    return " ".join(re.findall(r"[^\W_]+", normalized, flags=re.UNICODE))


def date_interval(value: str | None) -> tuple[date, date] | None:
    if not value:
        return None
    if not re.fullmatch(r"\d{4}(?:-\d{2}(?:-\d{2})?)?", value):
        raise ValueError("effective_date must be YYYY, YYYY-MM, or YYYY-MM-DD")
    fields = [int(p) for p in value.split("-")]
    if len(fields) == 1:
        return date(fields[0], 1, 1), date(fields[0], 12, 31)
    if len(fields) == 2:
        return date(fields[0], fields[1], 1), date(fields[0], fields[1], calendar.monthrange(fields[0], fields[1])[1])
    exact = date(*fields)
    return exact, exact


def temporal_overlap(a: str | None, b: str | None) -> bool:
    """Unknown dates conservatively overlap; partial dates are date ranges."""
    ia, ib = date_interval(a), date_interval(b)
    if not ia or not ib:
        return True
    return ia[0] <= ib[1] and ib[0] <= ia[1]
