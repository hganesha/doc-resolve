from __future__ import annotations

from typing import Any, Callable, TypedDict

from langgraph.graph import END, START, StateGraph
from langgraph.types import interrupt
from pydantic import ValidationError

from .chunking import build_chunks
from .config import requirements_for, select_profile
from .coverage import complete_section_inventory, compute_coverage
from .evidence import make_issue, verify_candidates
from .extraction import OpenAICompatible, ProviderError, rules_extract
from .parsing import parse_file
from .reconciliation import reconcile
from .store import EvidenceStore
from .util import digest, json_text, utc_now

# Increment whenever extraction prompts, rules, or output schema change.
EXTRACTION_CACHE_VERSION = "1"


class PipelineState(TypedDict, total=False):
    run_id: str
    case_id: str
    started_at: str
    doc_path: str
    requested_profile: str | None
    contract: dict
    extractor: str
    embeddings: str
    allow_remote: bool
    verify_material: bool
    model: str
    embedding_model: str
    provider_endpoint_sha256: str | None
    retry_from_run: str | None
    expected_document_sha256: str | None
    document: dict
    profile_id: str
    profile: dict
    requirements: list[dict]
    segments: list[dict]
    chunks: list[dict]
    sections: list[dict]
    parse_issues: list[dict]
    index_issues: list[dict]
    extraction_log: list[dict]
    evidence: list[dict]
    facts: list[dict]
    issues: list[dict]
    findings: list[dict]
    case_revision: str
    coverage: list[dict]
    review_decisions: list[dict]
    persisted: bool


def _provider(state: PipelineState) -> OpenAICompatible:
    return OpenAICompatible(allow_remote=state["allow_remote"], model=state.get("model"), embedding_model=state.get("embedding_model"))


def validate_review_response(response: Any, issues: list[dict]) -> list[dict]:
    if not isinstance(response, dict):
        raise ValueError("Review response must be a JSON object")
    reviewer = response.get("reviewer_id")
    if not isinstance(reviewer, str) or not reviewer.strip() or len(reviewer) > 150:
        raise ValueError("Review requires a nonempty reviewer_id (self-reported, not authenticated)")
    decisions = response.get("decisions")
    if not isinstance(decisions, list):
        raise ValueError("Review requires a decisions array")
    reviewable = {i["issue_id"]: i for i in issues if i["status"] == "OPEN" and i["severity"] == "high"}
    if len(decisions) != len(reviewable):
        raise ValueError("Provide exactly one decision for each review item")
    seen: set[str] = set()
    normalized = []
    for d in decisions:
        if not isinstance(d, dict) or d.get("issue_id") not in reviewable or d.get("issue_id") in seen:
            raise ValueError("Review contains an unknown or duplicate issue_id")
        issue = reviewable[d["issue_id"]]
        action = d.get("action")
        if action not in issue["allowed_actions"]:
            raise ValueError(f"Action is not permitted for issue {issue['issue_id']}")
        reason = d.get("reason")
        if not isinstance(reason, str) or not reason.strip() or len(reason) > 2000:
            raise ValueError("Every decision requires a nonempty reason, at most 2000 characters")
        selected = d.get("selected_fact_ids", [])
        if not isinstance(selected, list) or any(not isinstance(x, str) for x in selected):
            raise ValueError("selected_fact_ids must be an array of fact IDs")
        if action == "resolve" and (len(selected) != 1 or selected[0] not in issue["fact_ids"]):
            raise ValueError("Resolving a conflict requires selecting exactly one fact from that issue")
        if action == "defer" and selected:
            raise ValueError("Do not select a fact when deferring")
        seen.add(issue["issue_id"])
        normalized.append({"issue_id": issue["issue_id"], "action": action, "reason": reason.strip(), "selected_fact_ids": selected, "reviewer_id": reviewer.strip(), "reviewed_at": utc_now(), "reviewer_identity_authenticated": False})
    return normalized


def build_graph(store: EvidenceStore, checkpointer: Any, provider_factory: Callable[[PipelineState], Any] = _provider):
    def parse_node(state: PipelineState) -> dict:
        document, segments, parse_issues = parse_file(state["doc_path"])
        expected = state.get("expected_document_sha256")
        if expected and expected != document["sha256"]:
            raise ValueError("The retry input differs from the original document; start a fresh ingestion instead")
        sample = "\n".join(s["text"] for s in segments[:50])[:20000]
        profile_id, profile = select_profile(state["contract"], state.get("requested_profile"), document["filename"], sample)
        requirements = requirements_for(state["contract"], profile)
        return {"document": document, "segments": segments, "parse_issues": parse_issues, "profile_id": profile_id, "profile": profile, "requirements": requirements}

    def chunk_node(state: PipelineState) -> dict:
        chunks, sections, warnings = build_chunks(state["segments"], state["profile"])
        return {"chunks": chunks, "sections": sections, "parse_issues": state["parse_issues"] + warnings}

    def index_node(state: PipelineState) -> dict:
        chunks = [dict(c) for c in state["chunks"]]
        failures = 0
        if state["embeddings"] == "openai":
            provider = provider_factory(state)
            for start in range(0, len(chunks), 32):
                group = chunks[start:start + 32]
                try:
                    vectors = provider.embed([((c.get("table_header") or "") + "\n" + c["text"]).strip() for c in group])
                    for c, vector in zip(group, vectors):
                        c["embedding"] = vector
                        c["embedding_model"] = state["embedding_model"]
                except ProviderError:
                    failures += len(group)
            if hasattr(provider, "client"):
                provider.client.close()
        issues = []
        if failures:
            issues.append(make_issue("EMBEDDING_INDEX_INCOMPLETE", "Some dense embeddings could not be created; lexical retrieval remains available.", document_id=state["document"]["document_id"], categories=["*"], severity="medium", details={"failed_chunks": failures}))
        return {"chunks": chunks, "index_issues": issues}

    def extract_node(state: PipelineState) -> dict:
        provider = provider_factory(state) if state["extractor"] == "openai" else None
        current_units = store.get_extraction_units(state["run_id"])
        old_units = store.get_extraction_units(state["retry_from_run"]) if state.get("retry_from_run") else {}
        logs = []
        for chunk in state["chunks"]:
            cache_fingerprint = digest(json_text({"version": EXTRACTION_CACHE_VERSION, "chunk_id": chunk["chunk_id"], "profile_id": state["profile_id"], "profiles_sha256": state["contract"]["profiles_sha256"], "policy_sha256": state["contract"]["policy_sha256"], "extractor": state["extractor"], "model": state.get("model") if state["extractor"] == "openai" else None, "provider_endpoint_sha256": state.get("provider_endpoint_sha256") if state["extractor"] == "openai" else None}))
            cached = current_units.get(chunk["chunk_id"]) or old_units.get(chunk["chunk_id"])
            if cached and cached.get("status") == "OK" and cached.get("cache_fingerprint") == cache_fingerprint:
                log = {**cached, "reused_from_run": state.get("retry_from_run") or state["run_id"]}
            else:
                try:
                    candidates = provider.extract(chunk, state["requirements"]) if provider else rules_extract(chunk, state["requirements"])
                    log = {"chunk_id": chunk["chunk_id"], "status": "OK", "method": state["extractor"], "candidate_count": len(candidates), "candidates": candidates}
                except (ProviderError, ValidationError, ValueError) as exc:
                    # Never serialize provider responses or source content as an error.
                    safe = str(exc) if isinstance(exc, ProviderError) else "Candidate extraction or validation failed"
                    log = {"chunk_id": chunk["chunk_id"], "status": "ERROR", "method": state["extractor"], "candidate_count": 0, "candidates": [], "error": safe}
            log["cache_fingerprint"] = cache_fingerprint
            store.put_extraction_unit(state["run_id"], log)
            logs.append(log)
        if provider is not None and hasattr(provider, "client"):
            provider.client.close()
        return {"extraction_log": logs}

    def verify_node(state: PipelineState) -> dict:
        provider = provider_factory(state) if state.get("verify_material") else None
        evidence, facts, issues, logs = verify_candidates(state["document"], state["segments"], state["chunks"], state["extraction_log"], state["requirements"], provider, state.get("verify_material", False))
        if provider is not None and hasattr(provider, "client"):
            provider.client.close()
        for log in logs:
            if log["status"] != "OK":
                store.mark_unit_error(state["run_id"], log["chunk_id"], log.get("error", "Extraction failed"))
        parse_issues = [make_issue("PARSE_OR_STRUCTURE_INCOMPLETE", item["message"], document_id=state["document"]["document_id"], categories=["*"], details={k: v for k, v in item.items() if k != "message"}) for item in state["parse_issues"]]
        failed = [x for x in logs if x["status"] != "OK"]
        extraction_issues = []
        if failed:
            extraction_issues.append(make_issue("EXTRACTION_FAILED", "One or more chunks failed extraction or citation validation; retry or review them before relying on coverage.", document_id=state["document"]["document_id"], categories=["*"], details={"failed_count": len(failed), "chunk_ids": [x["chunk_id"] for x in failed], "error_types": sorted({x.get("error", "Extraction failed") for x in failed})}))
        return {"evidence": evidence, "facts": facts, "issues": issues + parse_issues + extraction_issues + state["index_issues"], "extraction_log": logs}

    def reconcile_node(state: PipelineState) -> dict:
        revision, previous = store.get_case_snapshot(state["case_id"], exclude_document_id=state["document"]["document_id"])
        findings, issues = reconcile(state["document"], state["facts"], previous, state["issues"])
        return {"findings": findings, "issues": issues, "case_revision": revision}

    def review_node(state: PipelineState) -> dict:
        items = [i for i in state["issues"] if i["status"] == "OPEN" and i["severity"] == "high"]
        if not items:
            return {"review_decisions": []}
        fact_map = {f["fact_id"]: f for f in state["facts"]}
        # Cross-document conflict facts are already persisted and must also be shown.
        fact_map.update({f["fact_id"]: f for f in store.get_current_facts(state["case_id"], exclude_document_id=state["document"]["document_id"])})
        related = sorted({fid for item in items for fid in item["fact_ids"]})
        related_facts = [fact_map[fid] for fid in related if fid in fact_map]
        ev_map = {e["evidence_id"]: e for e in store.export_case(state["case_id"])["evidence"]}
        ev_map.update({e["evidence_id"]: e for e in state["evidence"]})
        related_evidence_ids = sorted({eid for fact in related_facts for eid in fact["evidence_ids"]})
        request = {"run_id": state["run_id"], "case_id": state["case_id"], "document_id": state["document"]["document_id"], "issues": items, "facts": related_facts, "evidence": [ev_map[eid] for eid in related_evidence_ids if eid in ev_map], "instructions": "Review every issue against the source; resolve only where permitted, or defer. A selection is a self-reported human judgment, not an authenticated KYC decision."}
        response = interrupt(request)
        decisions = validate_review_response(response, state["issues"])
        by_issue = {d["issue_id"]: d for d in decisions}
        issues = []
        for item in state["issues"]:
            issue = dict(item)
            decision = by_issue.get(issue["issue_id"])
            if decision and decision["action"] == "resolve":
                issue["status"] = "RESOLVED_BY_HUMAN"
                issue["selected_fact_ids"] = decision["selected_fact_ids"]
            issues.append(issue)
        issue_map = {i["issue_id"]: i for i in issues}
        findings = [{**f, "status": issue_map[f["issue_id"]]["status"]} if f.get("issue_id") in issue_map else f for f in state["findings"]]
        return {"issues": issues, "findings": findings, "review_decisions": decisions}

    def coverage_node(state: PipelineState) -> dict:
        coverage = compute_coverage(state["requirements"], state["chunks"], state["extraction_log"], state["facts"], state["issues"], state["extractor"])
        sections = complete_section_inventory(state["sections"], state["chunks"], state["extraction_log"])
        return {"coverage": coverage, "sections": sections}

    def persist_node(state: PipelineState) -> dict:
        store.persist_run(state)
        return {"persisted": True}

    graph = StateGraph(PipelineState)
    graph.add_node("parse_and_classify", parse_node)
    graph.add_node("structure_and_chunk", chunk_node)
    graph.add_node("index", index_node)
    graph.add_node("extract_document_wide", extract_node)
    graph.add_node("validate_source", verify_node)
    graph.add_node("reconcile", reconcile_node)
    graph.add_node("human_review", review_node)
    graph.add_node("coverage_ledger", coverage_node)
    graph.add_node("persist", persist_node)
    graph.add_edge(START, "parse_and_classify")
    graph.add_edge("parse_and_classify", "structure_and_chunk")
    graph.add_edge("structure_and_chunk", "index")
    graph.add_edge("index", "extract_document_wide")
    graph.add_edge("extract_document_wide", "validate_source")
    graph.add_edge("validate_source", "reconcile")
    graph.add_edge("reconcile", "human_review")
    graph.add_edge("human_review", "coverage_ledger")
    graph.add_edge("coverage_ledger", "persist")
    graph.add_edge("persist", END)
    return graph.compile(checkpointer=checkpointer)
