from __future__ import annotations

import csv
import io
import re
from pathlib import Path
from typing import Any

import pymupdf as fitz
from bs4 import BeautifulSoup, NavigableString, Tag

from .util import digest, stable_id

MAX_INPUT_BYTES = 50 * 1024 * 1024


def _new_segment(segments: list[dict], document_id: str, *, text: str, kind: str, section_path: list[str], locator: str, page: int | None = None, bbox: list[float] | None = None, representation: str = "normalized_text", metadata: dict | None = None) -> None:
    text = text.strip()
    if not text:
        return
    path = list(section_path) or ["Document"]
    segment_id = stable_id("seg", document_id, locator, text)
    segments.append({
        "segment_id": segment_id,
        "document_id": document_id,
        "ordinal": len(segments),
        "kind": kind,
        "section_path": path,
        "section_id": stable_id("sec", document_id, path),
        "locator": locator,
        "page": page,
        "bbox": bbox,
        "representation": representation,
        "text": text,
        "text_sha256": digest(text),
        "metadata": metadata or {},
    })


def _update_heading(headings: list[str], level: int, title: str) -> list[str]:
    # Do not invent missing heading levels.
    headings = headings[: max(0, level - 1)]
    headings.append(title.strip())
    return headings


def _is_footnote(s: str) -> bool:
    return bool(re.match(r"^(?:\[\^[^\]]+\]:|(?:footnote|note)\s+\d+\s*[:.])", s, re.I))


def _parse_text(raw: bytes, document_id: str) -> tuple[list[dict], list[dict], int | None]:
    try:
        content = raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("Text files must be UTF-8") from exc
    content = content.replace("\r\n", "\n").replace("\r", "\n")
    has_pages = "\f" in content
    pages = content.split("\f")
    page_count = len(pages) if has_pages else None
    headings: list[str] = []
    segments: list[dict] = []
    line_base = 1
    for page_idx, page_text in enumerate(pages):
        lines = page_text.splitlines()
        page = page_idx + 1 if has_pages else None
        i = 0
        while i < len(lines):
            line = lines[i]
            stripped = line.strip()
            if not stripped:
                i += 1
                continue
            locator = f"page:{page}/line:{line_base + i}" if page else f"line:{line_base + i}"
            heading = re.match(r"^(#{1,6})\s+(.+?)\s*#*\s*$", stripped)
            if heading:
                headings = _update_heading(headings, len(heading.group(1)), heading.group(2))
                _new_segment(segments, document_id, text=stripped, kind="heading", section_path=headings, locator=locator, page=page)
                i += 1
                continue
            if "|" in stripped and stripped.count("|") >= 2:
                table_lines = []
                while i < len(lines) and lines[i].strip() and lines[i].count("|") >= 2:
                    table_lines.append(lines[i].strip())
                    i += 1
                _new_segment(segments, document_id, text="\n".join(table_lines), kind="table", section_path=headings, locator=locator, page=page, representation="normalized_markdown_table")
                continue
            if _is_footnote(stripped):
                _new_segment(segments, document_id, text=stripped, kind="footnote", section_path=headings, locator=locator, page=page)
                i += 1
                continue
            para = [stripped]
            i += 1
            while i < len(lines):
                nxt = lines[i].strip()
                if not nxt or re.match(r"^#{1,6}\s+", nxt) or ("|" in nxt and nxt.count("|") >= 2) or _is_footnote(nxt):
                    break
                para.append(nxt)
                i += 1
            _new_segment(segments, document_id, text="\n".join(para), kind="paragraph", section_path=headings, locator=locator, page=page)
        line_base += len(lines)
    issues: list[dict] = []
    if not segments:
        issues.append({"code": "EMPTY_DOCUMENT", "message": "No text could be parsed.", "page": None})
    return segments, issues, page_count


def _pdf_heading(text: str) -> tuple[int, str] | None:
    clean = " ".join(text.split())
    if len(clean) > 100 or len(clean.split()) > 12:
        return None
    if re.match(r"^\d+(?:\.\d+){0,3}\.?\s+[A-Z]", clean):
        return min(6, clean.split()[0].count(".") + 1), clean
    letters = [c for c in clean if c.isalpha()]
    if len(letters) >= 4 and all(c.isupper() for c in letters):
        return 1, clean
    return None


def _table_text(rows: list[list[Any]]) -> str:
    result = []
    for row in rows:
        cells = [" ".join(str(cell or "").split()) for cell in row]
        if any(cells):
            result.append("| " + " | ".join(cells) + " |")
    return "\n".join(result)


def _parse_pdf(raw: bytes, document_id: str) -> tuple[list[dict], list[dict], int]:
    segments: list[dict] = []
    issues: list[dict] = []
    headings: list[str] = []
    try:
        doc = fitz.open(stream=raw, filetype="pdf")
    except Exception as exc:
        raise ValueError("PDF could not be opened") from exc
    try:
        if doc.needs_pass:
            raise ValueError("Encrypted PDFs are not supported; supply a decrypted copy")
        page_count = len(doc)
        for index, page in enumerate(doc):
            page_no = index + 1
            blocks = page.get_text("blocks", sort=True)
            text_blocks = [b for b in blocks if len(b) > 6 and b[6] == 0 and str(b[4]).strip()]
            text_length = sum(len(str(b[4]).strip()) for b in text_blocks)
            if text_length < 20:
                issues.append({"code": "PDF_PAGE_TEXT_INSUFFICIENT", "message": "Page has little or no extractable text; a blank or scanned/image page requires assessment or OCR.", "page": page_no})
            page_area = max(float(page.rect.get_area()), 1.0)
            try:
                images = page.get_image_info()
                if any(float(fitz.Rect(info["bbox"]).get_area()) / page_area >= 0.30 for info in images):
                    issues.append({"code": "PDF_LARGE_IMAGE_UNREVIEWED", "message": "A substantial page image was not OCR'd; its content may contain material evidence.", "page": page_no})
            except Exception:
                issues.append({"code": "PDF_IMAGE_INSPECTION_FAILED", "message": "Could not inspect page images for missing text.", "page": page_no})
            events = []
            for b in text_blocks:
                events.append((float(b[1]), float(b[0]), "block", b))
            try:
                # PyMuPDF's table diagnostics should not corrupt CLI JSON output.
                import contextlib
                with contextlib.redirect_stdout(io.StringIO()):
                    tables = list(page.find_tables().tables)
                for ti, table in enumerate(tables):
                    events.append((float(table.bbox[1]), float(table.bbox[0]), "table", (ti, table)))
            except Exception:
                issues.append({"code": "PDF_TABLE_INSPECTION_FAILED", "message": "Table detection failed; raw text remains available but table context needs review.", "page": page_no})
            events.sort(key=lambda e: (e[0], e[1], 0 if e[2] == "table" else 1))
            for _, _, typ, item in events:
                if typ == "block":
                    b = item
                    text = str(b[4]).strip()
                    heading = _pdf_heading(text)
                    if heading:
                        headings = _update_heading(headings, heading[0], heading[1])
                    kind = "heading" if heading else "footnote" if _is_footnote(text) else "paragraph"
                    _new_segment(segments, document_id, text=text, kind=kind, section_path=headings, locator=f"page:{page_no}/block:{b[5]}", page=page_no, bbox=[round(float(x), 2) for x in b[:4]], representation="pymupdf_text_block")
                else:
                    ti, table = item
                    text = _table_text(table.extract())
                    _new_segment(segments, document_id, text=text, kind="table", section_path=headings, locator=f"page:{page_no}/table:{ti}", page=page_no, bbox=[round(float(x), 2) for x in table.bbox], representation="reconstructed_pdf_table", metadata={"note": "Table cell text and separators are reconstructed; visually verify against the source PDF."})
    finally:
        doc.close()
    if not segments:
        issues.append({"code": "EMPTY_DOCUMENT", "message": "No extractable PDF text was found.", "page": None})
    return segments, issues, page_count


def _html_table(tag: Tag) -> str:
    rows = []
    for tr in tag.find_all("tr"):
        cells = [cell.get_text(" ", strip=True) for cell in tr.find_all(["th", "td"], recursive=False)]
        if cells:
            rows.append(cells)
    return _table_text(rows)


def _parse_html(raw: bytes, document_id: str) -> tuple[list[dict], list[dict], None]:
    soup = BeautifulSoup(raw, "html.parser")
    scripts_present = any(tag.get("src") or tag.get_text(strip=True) for tag in soup.find_all("script"))
    embedded_present = bool(soup.find(["iframe", "object", "embed"]))
    images_present = bool(soup.find("img"))
    for element in soup.find_all(["script", "style", "template"]):
        element.decompose()
    # Keep noscript fallback text as data; scripts are never executed.
    for element in soup.find_all("noscript"):
        element.unwrap()
    root = soup.body or soup
    selected = {"h1", "h2", "h3", "h4", "h5", "h6", "p", "li", "table", "blockquote", "pre"}
    containers = {"div", "section", "article"}
    def is_unit(tag: Tag) -> bool:
        if tag.name in selected:
            return True
        return bool(tag.name in containers and not tag.find(list(selected | containers)))
    segments: list[dict] = []
    headings: list[str] = []
    node_no = 0
    orphan_text_count = 0
    merged_table_count = 0
    for node in root.descendants:
        if isinstance(node, Tag):
            if not is_unit(node) or any(isinstance(p, Tag) and is_unit(p) for p in node.parents if p is not root):
                continue
            node_no += 1
            locator = f"html-id:{node.get('id')}/node:{node_no}" if node.get("id") else f"html-node:{node_no}"
            text = _html_table(node) if node.name == "table" else node.get_text(" ", strip=True)
            if node.name and re.fullmatch(r"h[1-6]", node.name):
                headings = _update_heading(headings, int(node.name[1]), text)
                kind = "heading"
            elif node.name == "table":
                kind = "table"
                if any(cell.get("rowspan", "1") != "1" or cell.get("colspan", "1") != "1" for cell in node.find_all(["th", "td"])):
                    merged_table_count += 1
            else:
                kind = "footnote" if _is_footnote(text) or str(node.get("id", "")).lower().startswith(("fn", "footnote")) else "paragraph"
            links = [a.get("href") for a in node.find_all("a", href=True) if str(a.get("href")).startswith("#")]
            _new_segment(segments, document_id, text=text, kind=kind, section_path=headings, locator=locator, representation="reconstructed_html_table" if kind == "table" else "normalized_html_text", metadata={"internal_links": links})
        elif isinstance(node, NavigableString):
            if any(isinstance(p, Tag) and is_unit(p) for p in node.parents if p is not root):
                continue
            text = str(node).strip()
            if text:
                node_no += 1
                orphan_text_count += 1
                _new_segment(segments, document_id, text=text, kind="paragraph", section_path=headings, locator=f"html-text:{node_no}", representation="normalized_html_text")
    issues = [] if segments else [{"code": "EMPTY_DOCUMENT", "message": "No visible static HTML content was found; JavaScript is not executed.", "page": None}]
    if scripts_present:
        issues.append({"code": "HTML_DYNAMIC_CONTENT_NOT_RENDERED", "message": "HTML contains scripts that were not executed; dynamically rendered content may be missing.", "page": None})
    if embedded_present:
        issues.append({"code": "HTML_EMBEDDED_CONTENT_NOT_LOADED", "message": "Embedded HTML content was not fetched; review the original page and embedded sources.", "page": None})
    if images_present:
        issues.append({"code": "HTML_IMAGES_NOT_OCR", "message": "HTML images were not fetched or OCR'd; they may contain material evidence.", "page": None})
    if orphan_text_count:
        issues.append({"code": "HTML_UNSCOPED_TEXT", "message": "Some visible HTML text fell outside recognized structural blocks and may be fragmented; review the original page.", "page": None, "count": orphan_text_count})
    if merged_table_count:
        issues.append({"code": "HTML_MERGED_TABLE_CELLS", "message": "Merged HTML table cells were not expanded; verify table headers and row relationships manually.", "page": None, "count": merged_table_count})
    return segments, issues, None


def _parse_csv(raw: bytes, document_id: str) -> tuple[list[dict], list[dict], None]:
    try:
        content = raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("CSV files must be UTF-8") from exc
    reader = csv.reader(io.StringIO(content, newline=""))
    rows = list(reader)
    segments: list[dict] = []
    if rows:
        header = rows[0]
        for i, row in enumerate(rows[1:], 2):
            table_text = _table_text([header, row])
            _new_segment(segments, document_id, text=table_text, kind="table", section_path=["Records"], locator=f"csv-row:{i}", representation="reconstructed_csv_record", metadata={"row_number": i, "note": "Headers are repeated as context; separators are reconstructed."})
    issues = [] if segments else [{"code": "EMPTY_DOCUMENT", "message": "CSV has no data rows.", "page": None}]
    return segments, issues, None


def parse_file(path: str) -> tuple[dict, list[dict], list[dict]]:
    p = Path(path)
    if not p.is_file():
        raise ValueError("Input document does not exist or is not a regular file")
    if p.stat().st_size > MAX_INPUT_BYTES:
        raise ValueError("Input exceeds the 50 MiB proof-of-concept limit")
    raw = p.read_bytes()
    sha = digest(raw)
    document_id = "doc_" + sha[:24]
    suffix = p.suffix.lower()
    if suffix in {".txt", ".md", ".markdown"}:
        segments, issues, page_count = _parse_text(raw, document_id)
    elif suffix in {".html", ".htm"}:
        segments, issues, page_count = _parse_html(raw, document_id)
    elif suffix == ".csv":
        segments, issues, page_count = _parse_csv(raw, document_id)
    elif suffix == ".pdf":
        segments, issues, page_count = _parse_pdf(raw, document_id)
    else:
        raise ValueError("Unsupported format. Use UTF-8 TXT/Markdown, static HTML, CSV, or a text-based PDF")
    document = {"document_id": document_id, "filename": p.name, "sha256": sha, "bytes": len(raw), "format": suffix.lstrip("."), "page_count": page_count}
    return document, segments, issues
